
function showResult() {
  const input = document.getElementById('birthInput').value;
  if (!input) {
    alert('년월일시를 입력해주세요.');
    return;
  }

  // 예시 결과 출력 (향후 사주 오주괘 계산 로직 삽입 가능)
  document.getElementById('result').innerText = `입력된 값: ${input}\n→ 오주괘 결과 예시입니다.`;
}
